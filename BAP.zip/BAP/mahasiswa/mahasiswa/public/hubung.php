<?php

$hubung = mysqli_connect ("localhost", "BAP", "B@p", "KRS")

?>